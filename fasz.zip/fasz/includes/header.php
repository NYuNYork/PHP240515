<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gyíkoldal<?php if(isset($title)){echo $title;} ?></title> 
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="js/bootstrap.bundle.js"></script>
</head>
<body>
    <nav class="navbar navbar-expand-sm bg-dark navbar-light px-1">
        <div class="container-fluid">
            <a class="navbar-brand" href="./">
                <img src="img/gyik.png" alt="Logo" style="width:60px;" class="rounded-pill">
            </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav ms-auto">
              <li class="nav-item">
                <a class="nav-link" href="elso.php">Első oldal</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="masodik.php">Második oldal</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="masodik.php">harmadik oldal</a>
              </li>    
            </ul>
          </div>
        </div>
    </nav>