<?php
    $title = "Főoldal"; 
    include("includes/header.php")
?>
    <main class="container">
        <section class="pt-3">
            <h2 class="pt-2">Főoldal</h2>
            <div class="row">
                <div class="col-sm">
                    <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque est ab rerum. In delectus, assumenda inventore eaque quaerat numquam modi, alias perspiciatis officia officiis at, quia vel soluta natus minus!
                    </p>
                </div>
                <div class="col-sm">
                    <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam aperiam, exercitationem, dignissimos reprehenderit minus fugiat sapiente in soluta itaque repellendus eos, sit accusantium ipsam ducimus quibusdam ea culpa dicta est.
                    </p>
                </div>
            </div>
        </section>
    </main>
<?php
    include("includes/footer.php")
?>
