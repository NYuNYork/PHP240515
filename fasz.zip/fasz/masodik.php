<?php
    include("includes/header.php")
?>
    <main class="container">
    <section class="pt-3">
          <h2 class="pt-2">Második oldal</h2>
          
        </section>
    </main>
    
<?php
    include("includes/footer.php")
?>