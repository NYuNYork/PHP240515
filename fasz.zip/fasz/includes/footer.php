<footer class="container pb-5 pt-1">
      <div>
        <div><p>Adatvédelem</p></div>
        <div><p class="w-100 text-end">Felhasználói feltételek</p></div>
      </div>
    </footer>
</body>
</html>