<?php
$title = "képgaléria";
    include("includes/header.php")
?>
    <main class="container">
    <section class="pt-3">
          <h2 class="pt-2">Első oldal</h2>
          <div class="row">
            <div class="col-sm-6">
              <p>
                <img src="img/01.jpg" alt="01.jpg" class="img-fluid border border-dark border-5 rounded">
              </p>
            </div>
            <div class="col-sm-6">
              <p>
                <img src="img/02.jpg" alt="02.jpg" class="w-100 border border-dark border-5 rounded">
              </p>
            </div>
            <div class="col-sm-6">
              <p>
                <img src="img/03.jpg" alt="03.jpg" class="w-100 border border-dark border-5 rounded">
              </p>
            </div>
            <div class="col-sm-6">
              <p>
                <img src="img/04.jpg" alt="04.jpg" class="w-100 border border-dark border-5 rounded">
              </p>
            </div>
          </div>
        </section>
    </main>
    
<?php
    include("includes/footer.php")
?>